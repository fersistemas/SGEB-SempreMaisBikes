if (isset($_POST['produto1'])){
    $produto1 = $_POST['produto1'];
}	
else{
    $produto1 = null;
}

if (isset($_POST['produto2'])){
    $produto2 = $_POST['produto2'];
}	
else{
    $produto2 = "nulo!";
}

if (isset($_POST['produto3'])){
    $produto2 = $_POST['produto3'];
}	
else{
    $produto2 = "nulo!";
}

if (isset($_POST['produto4'])){
    $produto2 = $_POST['produto4'];
}	
else{
    $produto2 = "nulo!";
}

if (isset($_POST['produto5'])){
    $produto2 = $_POST['produto5'];
}	
else{
    $produto2 = "nulo!";
}

if (isset($_POST['produto6'])){
    $produto2 = $_POST['produto6'];
}	
else{
    $produto2 = "nulo!";
}

if (isset($_POST['produto7'])){
    $produto2 = $_POST['produto7'];
}	
else{
    $produto2 = "nulo!";
}

if (isset($_POST['produto8'])){
    $produto2 = $_POST['produto8'];
}	
else{
    $produto2 = "nulo!";
}

if (isset($_POST['produto9'])){
    $produto2 = $_POST['produto9'];
}	
else{
    $produto2 = "nulo!";
}

if (isset($_POST['produto10'])){
    $produto2 = $_POST['produto10'];
}	
else{
    $produto2 = "nulo!";
}