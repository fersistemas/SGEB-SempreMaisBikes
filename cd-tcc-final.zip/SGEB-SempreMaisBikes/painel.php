<?php include('inc/header_painelAdm.php'); ?>


<div class="box_center">
		<div class="card">
			<div class="card-header">
				<h4 style="text-align: center; vertical-align:middle !important" class="well"> Bem vindo :<?php $usuario ?>  </h4> <!-- Título da tabela -->
			</div>
			<div class="card-body">
				
				
				
			</div>
		</div>
    </div>	
	




<?php include('inc/footer.php'); ?>