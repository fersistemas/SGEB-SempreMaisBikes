<?php include('inc/header_painelAdm.php'); ?>

<div class="container_main">
		<div class="box_center">
			<div class="card">
				<div class="card-header">
					<h4 style="text-align: center; vertical-align:middle !important" class="well"> Backup </h4>
				</div>
				<div class="card-body">
					<label class="control-label">Backup Feito! </label>

				</div>
			</div>
		</div>				
	</div>
</div>
<?php include('inc/footer.php'); ?>

